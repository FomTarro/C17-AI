AI Assignment #1 1/27/17 - Tom Farro, Kelly Zhang, Miya Gaskell, Alex Guerra

TO RUN A*:
- Make sure you have a recent version of Node.js installed
- Place your desired map file in the directory where you extracted this project to
- Open terminal and enter:
	node AStar.js "<map file>" <heuristic number>
- Observe output in terminal

OTHER NOTES:
- You can generate and explore a random map by typing:
	node AStar.js random <heuristic number>
- This randomized map outputs to "random.txt" in the project directory